from sklearn.metrics import precision_score, recall_score, accuracy_score, mean_squared_error, mean_absolute_error, r2_score


def compute_evaluation_metrics(y_true, y_pred):
    """
    Args:
        y_true: true labels
        y_pred: predicted labels
    Returns:
        precision: precision score
        recall: recall score
        accuracy: accuracy score
    """
    p = precision_score(y_true, y_pred)
    r = recall_score(y_true, y_pred)
    acc = accuracy_score(y_true, y_pred)
    return p, r, acc

def compute_evaluation_continuous_metrics(y_true, y_pred):
    """
    Args:
        y_true: true labels
        y_pred: predicted labels
    Returns:
        mse: mean squared error
        mae: mean absolute error
        r2: R-squared score
    """
    mse = mean_squared_error(y_true, y_pred)
    mae = mean_absolute_error(y_true, y_pred)
    r2 = r2_score(y_true, y_pred)
    return mse, mae, r2